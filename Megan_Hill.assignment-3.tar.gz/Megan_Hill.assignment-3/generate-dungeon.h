#ifndef CS327_GENERATE_DUNGEON_H
#define CS327_GENERATE_DUNGEON_H

void generateRandomFloor();
void saveDungeon(char *fileName);
void loadDungeon(char *fileName);

#endif //CS327_GENERATE_DUNGEON_H
