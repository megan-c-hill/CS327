#ifndef CS327_DIJKSTRA_H
#define CS327_DIJKSTRA_H

void tunnelingDistance(int x, int y);

void nonTunnelingDistance(int x, int y);

#endif //CS327_DIJKSTRA_H
