#ifndef CS327_DIJKSTRA_H
#define CS327_DIJKSTRA_H

void tunnelingDistance();
void nonTunnelingDistance();

#endif //CS327_DIJKSTRA_H
